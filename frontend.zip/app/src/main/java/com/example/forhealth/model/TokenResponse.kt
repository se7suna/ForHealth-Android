package com.example.forhealth.model

data class TokenResponse(
    val access_token: String
)
